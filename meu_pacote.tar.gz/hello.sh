echo 'Hello from ProteusOS'
